package com.example.model;


	import java.util.ArrayList;
	import java.util.List;

	public class �lExpert {

		public List<String> getBrands(String color) {
			List<String> brands = new ArrayList<>();
			
			if(color.toLowerCase().equals("Guld")) {
				brands.add("M�rke 1");
				brands.add("M�rke 2");
			}
			else if(color.toLowerCase().equals("m�rk guld")) {
				brands.add("M�rke 3");
				brands.add("M�rke 4");			
			}
			else if(color.toLowerCase().equals("m�rk")) {
				brands.add("M�rke 5");
				brands.add("M�rke 6");
			}
			else if(color.toLowerCase().equals("ljus")) {
				brands.add("M�rke 7");
				brands.add("M�rke 8");
				brands.add("M�rke 9");
			}
			return brands;
		}
	}


