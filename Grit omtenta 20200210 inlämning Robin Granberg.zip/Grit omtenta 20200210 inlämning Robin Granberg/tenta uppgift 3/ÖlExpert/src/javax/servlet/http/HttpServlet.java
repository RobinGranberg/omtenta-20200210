package javax.servlet.http;

public class HttpServlet {

}
